% Script to convert video files from HDA dataset
%
% Author: Juan C. SanMiguel (juancarlos.sanmiguel@uam.es)
% Date: September 2017

clearvars
close all
clc

%% add all directories for the toolbox
addpath(genpath(['./toolbox/']));

%% conversion settings

%path to the root directory of the HDA dataset
workingDir = 'C:\Users\vpu\Desktop\HDA_Dataset_V1.3';

%relative path with the image sequences
dataDir = 'hda_image_sequences_matlab';

%sequences to convert to video files
seqs = {'camera02','camera17','camera18','camera19','camera40','camera50','camera53','camera54','camera56','camera57','camera58','camera59','camera60'};

%fps for each video file
fps = {5,5,5,5,5,2,2,2,2,2,2,2,1};

%% Perform conversion for each video file

for ii = 1:numel(seqs)
   
    %path to data
    fName = fullfile(workingDir,dataDir,[seqs{ii} '.seq']);    
    
    %create directory & JPEGs
    tDir = fullfile(workingDir,dataDir,seqs{ii});
    mkdir(tDir);
    Is = seqIo( fName, 'toImgs', tDir);
    
    %create video
    outputVideo = VideoWriter(fullfile(workingDir,dataDir,[seqs{ii} '.avi']));
    outputVideo.FrameRate = fps{ii};
    open(outputVideo)
    
    imageNames = dir(fullfile(workingDir,dataDir,seqs{ii},'*.jpg'));
    imageNames = {imageNames.name}';
    
    h = waitbar(0,sprintf('Converting file %s...',seqs{ii}));
    for ff = 1:length(imageNames)
        img = imread(fullfile(workingDir,dataDir,seqs{ii},imageNames{ff}));
        writeVideo(outputVideo,img)
        waitbar(ff / length(imageNames));
    end
    
    close(outputVideo);
    
    %remove directory
    [status, message, messageid] = rmdir(tDir, 's');    
end