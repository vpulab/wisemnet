//
// Generated file, do not edit! Created by opp_msgc 4.5 from wise/src/node/application/wiseCameraCAWCTracker/WiseCameraCAWCTrackerPkt.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "WiseCameraCAWCTrackerPkt_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

EXECUTE_ON_STARTUP(
    cEnum *e = cEnum::find("WiseCAWCPacketType");
    if (!e) enums.getInstance()->add(e = new cEnum("WiseCAWCPacketType"));
    e->insert(CAWC_UTILITY, "CAWC_UTILITY");
    e->insert(CAWC_NEWMANAGER, "CAWC_NEWMANAGER");
    e->insert(CAWC_NEWMANAGER_ACK, "CAWC_NEWMANAGER_ACK");
    e->insert(CAWC_NEWMANAGER_ACK_SEND, "CAWC_NEWMANAGER_ACK_SEND");
    e->insert(CAWC_NEWMANAGER_SEND, "CAWC_NEWMANAGER_SEND");
    e->insert(CAWC_NEGOTIATION_JOIN, "CAWC_NEGOTIATION_JOIN");
    e->insert(CAWC_NEGOTIATION_REPLY, "CAWC_NEGOTIATION_REPLY");
    e->insert(CAWC_COLLABORATION_REQUEST, "CAWC_COLLABORATION_REQUEST");
    e->insert(CAWC_COLLABORATION_DATA, "CAWC_COLLABORATION_DATA");
    e->insert(CAWC_COLLABORATION_END, "CAWC_COLLABORATION_END");
);

Register_Class(WiseCameraCAWCTrackerPkt);

WiseCameraCAWCTrackerPkt::WiseCameraCAWCTrackerPkt(const char *name, int kind) : ::WiseApplicationPacket(name,kind)
{
    this->pktType_var = 0;
    this->nodeID_var = 0;
    this->camID_var = 0;
    this->utility_var = 0;
    this->priority_var = 0;
    this->battery_level_var = 0;
    this->load_level_var = 0;
    this->newManager_var = 0;
    this->reply_var = 0;
}

WiseCameraCAWCTrackerPkt::WiseCameraCAWCTrackerPkt(const WiseCameraCAWCTrackerPkt& other) : ::WiseApplicationPacket(other)
{
    copy(other);
}

WiseCameraCAWCTrackerPkt::~WiseCameraCAWCTrackerPkt()
{
}

WiseCameraCAWCTrackerPkt& WiseCameraCAWCTrackerPkt::operator=(const WiseCameraCAWCTrackerPkt& other)
{
    if (this==&other) return *this;
    ::WiseApplicationPacket::operator=(other);
    copy(other);
    return *this;
}

void WiseCameraCAWCTrackerPkt::copy(const WiseCameraCAWCTrackerPkt& other)
{
    this->pktType_var = other.pktType_var;
    this->nodeID_var = other.nodeID_var;
    this->camID_var = other.camID_var;
    this->utility_var = other.utility_var;
    this->priority_var = other.priority_var;
    this->battery_level_var = other.battery_level_var;
    this->load_level_var = other.load_level_var;
    this->newManager_var = other.newManager_var;
    this->x_var = other.x_var;
    this->P_var = other.P_var;
    this->reply_var = other.reply_var;
    this->z_var = other.z_var;
    this->H_var = other.H_var;
    this->Ht_var = other.Ht_var;
    this->Rinv_var = other.Rinv_var;
}

void WiseCameraCAWCTrackerPkt::parsimPack(cCommBuffer *b)
{
    ::WiseApplicationPacket::parsimPack(b);
    doPacking(b,this->pktType_var);
    doPacking(b,this->nodeID_var);
    doPacking(b,this->camID_var);
    doPacking(b,this->utility_var);
    doPacking(b,this->priority_var);
    doPacking(b,this->battery_level_var);
    doPacking(b,this->load_level_var);
    doPacking(b,this->newManager_var);
    doPacking(b,this->x_var);
    doPacking(b,this->P_var);
    doPacking(b,this->reply_var);
    doPacking(b,this->z_var);
    doPacking(b,this->H_var);
    doPacking(b,this->Ht_var);
    doPacking(b,this->Rinv_var);
}

void WiseCameraCAWCTrackerPkt::parsimUnpack(cCommBuffer *b)
{
    ::WiseApplicationPacket::parsimUnpack(b);
    doUnpacking(b,this->pktType_var);
    doUnpacking(b,this->nodeID_var);
    doUnpacking(b,this->camID_var);
    doUnpacking(b,this->utility_var);
    doUnpacking(b,this->priority_var);
    doUnpacking(b,this->battery_level_var);
    doUnpacking(b,this->load_level_var);
    doUnpacking(b,this->newManager_var);
    doUnpacking(b,this->x_var);
    doUnpacking(b,this->P_var);
    doUnpacking(b,this->reply_var);
    doUnpacking(b,this->z_var);
    doUnpacking(b,this->H_var);
    doUnpacking(b,this->Ht_var);
    doUnpacking(b,this->Rinv_var);
}

unsigned int WiseCameraCAWCTrackerPkt::getPktType() const
{
    return pktType_var;
}

void WiseCameraCAWCTrackerPkt::setPktType(unsigned int pktType)
{
    this->pktType_var = pktType;
}

int WiseCameraCAWCTrackerPkt::getNodeID() const
{
    return nodeID_var;
}

void WiseCameraCAWCTrackerPkt::setNodeID(int nodeID)
{
    this->nodeID_var = nodeID;
}

int WiseCameraCAWCTrackerPkt::getCamID() const
{
    return camID_var;
}

void WiseCameraCAWCTrackerPkt::setCamID(int camID)
{
    this->camID_var = camID;
}

double WiseCameraCAWCTrackerPkt::getUtility() const
{
    return utility_var;
}

void WiseCameraCAWCTrackerPkt::setUtility(double utility)
{
    this->utility_var = utility;
}

double WiseCameraCAWCTrackerPkt::getPriority() const
{
    return priority_var;
}

void WiseCameraCAWCTrackerPkt::setPriority(double priority)
{
    this->priority_var = priority;
}

double WiseCameraCAWCTrackerPkt::getBattery_level() const
{
    return battery_level_var;
}

void WiseCameraCAWCTrackerPkt::setBattery_level(double battery_level)
{
    this->battery_level_var = battery_level;
}

double WiseCameraCAWCTrackerPkt::getLoad_level() const
{
    return load_level_var;
}

void WiseCameraCAWCTrackerPkt::setLoad_level(double load_level)
{
    this->load_level_var = load_level;
}

int WiseCameraCAWCTrackerPkt::getNewManager() const
{
    return newManager_var;
}

void WiseCameraCAWCTrackerPkt::setNewManager(int newManager)
{
    this->newManager_var = newManager;
}

cv::Mat& WiseCameraCAWCTrackerPkt::getX()
{
    return x_var;
}

void WiseCameraCAWCTrackerPkt::setX(const cv::Mat& x)
{
    this->x_var = x;
}

cv::Mat& WiseCameraCAWCTrackerPkt::getP()
{
    return P_var;
}

void WiseCameraCAWCTrackerPkt::setP(const cv::Mat& P)
{
    this->P_var = P;
}

bool WiseCameraCAWCTrackerPkt::getReply() const
{
    return reply_var;
}

void WiseCameraCAWCTrackerPkt::setReply(bool reply)
{
    this->reply_var = reply;
}

cv::Mat& WiseCameraCAWCTrackerPkt::getZ()
{
    return z_var;
}

void WiseCameraCAWCTrackerPkt::setZ(const cv::Mat& z)
{
    this->z_var = z;
}

cv::Mat& WiseCameraCAWCTrackerPkt::getH()
{
    return H_var;
}

void WiseCameraCAWCTrackerPkt::setH(const cv::Mat& H)
{
    this->H_var = H;
}

cv::Mat& WiseCameraCAWCTrackerPkt::getHt()
{
    return Ht_var;
}

void WiseCameraCAWCTrackerPkt::setHt(const cv::Mat& Ht)
{
    this->Ht_var = Ht;
}

cv::Mat& WiseCameraCAWCTrackerPkt::getRinv()
{
    return Rinv_var;
}

void WiseCameraCAWCTrackerPkt::setRinv(const cv::Mat& Rinv)
{
    this->Rinv_var = Rinv;
}

class WiseCameraCAWCTrackerPktDescriptor : public cClassDescriptor
{
  public:
    WiseCameraCAWCTrackerPktDescriptor();
    virtual ~WiseCameraCAWCTrackerPktDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(WiseCameraCAWCTrackerPktDescriptor);

WiseCameraCAWCTrackerPktDescriptor::WiseCameraCAWCTrackerPktDescriptor() : cClassDescriptor("WiseCameraCAWCTrackerPkt", "WiseApplicationPacket")
{
}

WiseCameraCAWCTrackerPktDescriptor::~WiseCameraCAWCTrackerPktDescriptor()
{
}

bool WiseCameraCAWCTrackerPktDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<WiseCameraCAWCTrackerPkt *>(obj)!=NULL;
}

const char *WiseCameraCAWCTrackerPktDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int WiseCameraCAWCTrackerPktDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 15+basedesc->getFieldCount(object) : 15;
}

unsigned int WiseCameraCAWCTrackerPktDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISCOMPOUND,
        FD_ISCOMPOUND,
        FD_ISEDITABLE,
        FD_ISCOMPOUND,
        FD_ISCOMPOUND,
        FD_ISCOMPOUND,
        FD_ISCOMPOUND,
    };
    return (field>=0 && field<15) ? fieldTypeFlags[field] : 0;
}

const char *WiseCameraCAWCTrackerPktDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "pktType",
        "nodeID",
        "camID",
        "utility",
        "priority",
        "battery_level",
        "load_level",
        "newManager",
        "x",
        "P",
        "reply",
        "z",
        "H",
        "Ht",
        "Rinv",
    };
    return (field>=0 && field<15) ? fieldNames[field] : NULL;
}

int WiseCameraCAWCTrackerPktDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='p' && strcmp(fieldName, "pktType")==0) return base+0;
    if (fieldName[0]=='n' && strcmp(fieldName, "nodeID")==0) return base+1;
    if (fieldName[0]=='c' && strcmp(fieldName, "camID")==0) return base+2;
    if (fieldName[0]=='u' && strcmp(fieldName, "utility")==0) return base+3;
    if (fieldName[0]=='p' && strcmp(fieldName, "priority")==0) return base+4;
    if (fieldName[0]=='b' && strcmp(fieldName, "battery_level")==0) return base+5;
    if (fieldName[0]=='l' && strcmp(fieldName, "load_level")==0) return base+6;
    if (fieldName[0]=='n' && strcmp(fieldName, "newManager")==0) return base+7;
    if (fieldName[0]=='x' && strcmp(fieldName, "x")==0) return base+8;
    if (fieldName[0]=='P' && strcmp(fieldName, "P")==0) return base+9;
    if (fieldName[0]=='r' && strcmp(fieldName, "reply")==0) return base+10;
    if (fieldName[0]=='z' && strcmp(fieldName, "z")==0) return base+11;
    if (fieldName[0]=='H' && strcmp(fieldName, "H")==0) return base+12;
    if (fieldName[0]=='H' && strcmp(fieldName, "Ht")==0) return base+13;
    if (fieldName[0]=='R' && strcmp(fieldName, "Rinv")==0) return base+14;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *WiseCameraCAWCTrackerPktDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "unsigned int",
        "int",
        "int",
        "double",
        "double",
        "double",
        "double",
        "int",
        "cv::Mat",
        "cv::Mat",
        "bool",
        "cv::Mat",
        "cv::Mat",
        "cv::Mat",
        "cv::Mat",
    };
    return (field>=0 && field<15) ? fieldTypeStrings[field] : NULL;
}

const char *WiseCameraCAWCTrackerPktDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int WiseCameraCAWCTrackerPktDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    WiseCameraCAWCTrackerPkt *pp = (WiseCameraCAWCTrackerPkt *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string WiseCameraCAWCTrackerPktDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    WiseCameraCAWCTrackerPkt *pp = (WiseCameraCAWCTrackerPkt *)object; (void)pp;
    switch (field) {
        case 0: return ulong2string(pp->getPktType());
        case 1: return long2string(pp->getNodeID());
        case 2: return long2string(pp->getCamID());
        case 3: return double2string(pp->getUtility());
        case 4: return double2string(pp->getPriority());
        case 5: return double2string(pp->getBattery_level());
        case 6: return double2string(pp->getLoad_level());
        case 7: return long2string(pp->getNewManager());
        case 8: {std::stringstream out; out << pp->getX(); return out.str();}
        case 9: {std::stringstream out; out << pp->getP(); return out.str();}
        case 10: return bool2string(pp->getReply());
        case 11: {std::stringstream out; out << pp->getZ(); return out.str();}
        case 12: {std::stringstream out; out << pp->getH(); return out.str();}
        case 13: {std::stringstream out; out << pp->getHt(); return out.str();}
        case 14: {std::stringstream out; out << pp->getRinv(); return out.str();}
        default: return "";
    }
}

bool WiseCameraCAWCTrackerPktDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    WiseCameraCAWCTrackerPkt *pp = (WiseCameraCAWCTrackerPkt *)object; (void)pp;
    switch (field) {
        case 0: pp->setPktType(string2ulong(value)); return true;
        case 1: pp->setNodeID(string2long(value)); return true;
        case 2: pp->setCamID(string2long(value)); return true;
        case 3: pp->setUtility(string2double(value)); return true;
        case 4: pp->setPriority(string2double(value)); return true;
        case 5: pp->setBattery_level(string2double(value)); return true;
        case 6: pp->setLoad_level(string2double(value)); return true;
        case 7: pp->setNewManager(string2long(value)); return true;
        case 10: pp->setReply(string2bool(value)); return true;
        default: return false;
    }
}

const char *WiseCameraCAWCTrackerPktDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 8: return opp_typename(typeid(cv::Mat));
        case 9: return opp_typename(typeid(cv::Mat));
        case 11: return opp_typename(typeid(cv::Mat));
        case 12: return opp_typename(typeid(cv::Mat));
        case 13: return opp_typename(typeid(cv::Mat));
        case 14: return opp_typename(typeid(cv::Mat));
        default: return NULL;
    };
}

void *WiseCameraCAWCTrackerPktDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    WiseCameraCAWCTrackerPkt *pp = (WiseCameraCAWCTrackerPkt *)object; (void)pp;
    switch (field) {
        case 8: return (void *)(&pp->getX()); break;
        case 9: return (void *)(&pp->getP()); break;
        case 11: return (void *)(&pp->getZ()); break;
        case 12: return (void *)(&pp->getH()); break;
        case 13: return (void *)(&pp->getHt()); break;
        case 14: return (void *)(&pp->getRinv()); break;
        default: return NULL;
    }
}


