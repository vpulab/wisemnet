// *****************************************************************************
//  Copyright (C): Juan C. SanMiguel, 2015
//  Author(s): Juan C. SanMiguel
//  Developed at EECS, Queen Mary University (London)
//  This file is distributed under the terms in the attached LICENSE_2 file.  
//  If you do not find this file, copies can be found by writing to:
//  - juan.carlos.sanmiguel@eecs.qmul.ac.uk
//  - andrea.cavallaro@eecs.qmul.ac.uk                                        
// *****************************************************************************

#include "WiseCameraCAWCTracker_utils.h"


using namespace CAWC;

#define RECT_IN_MAT(ROI, img) ( (ROI.area() > 0) && (ROI.br().y -1 < img.rows) && (ROI.br().x - 1 < img.cols) )

CamTracker::CamTracker(int id)
{
    _id = id;
    _struck = NULL;
    _conf = NULL;

    _started = false;
    _trackers_str = CAWC::create_tracker_str();
}

CamTracker::~CamTracker()
{
    if (_struck!=NULL){
        delete _struck;
        delete _conf;
    }
}

bool CamTracker::selectTracker(tracker_type_t type)
{
    _selTracker = type;

    switch (_selTracker) {

            case STRUCK:
                _conf = new Config("../../src/node/application/Trackers/struck/config.txt");
                _struck = new Tracker(*_conf);
                //cout << *_conf << endl;
                break;
            case TLD:
            case MIL:
            case BOOSTING:
            case MEDIANFLOW:
                _tracker = cv::Tracker::create( _trackers_str[_selTracker] );
                break;
            default:
                return false;
        }
    return true;
}

bool CamTracker::initialize(cv::Mat frame, target_initialization_t iniT)
{
    double resize = iniT.resize;

    switch (_selTracker)
    {
          case STRUCK:
          {
              FloatRect initBB = FloatRect((iniT.Xc-iniT.width/2)*resize, (iniT.Yc-iniT.height/2)*resize, iniT.width*resize, iniT.height*resize);
              _struck->Initialise(frame, initBB);
              _trackWindow = cv::Rect(_struck->GetBB().XMin(),_struck->GetBB().YMin(),_struck->GetBB().Width(),_struck->GetBB().Height());
              break;
          }
          case TLD:
          case MIL:
          case BOOSTING:
          case MEDIANFLOW:
              _trackWindow = cv::Rect((iniT.Xc-iniT.width/2)*resize, (iniT.Yc-iniT.height/2)*resize, iniT.width*resize, iniT.height*resize);
              if( !_tracker->init(frame, _trackWindow ) ) {

                 cout << "***ERROR! Cannot initialize tracker***\n";
                 return false;
              }
              break;
      }
   _started = true;
   _prevtrackWindow = _trackWindow;
   _frame = frame;
   _prevframe = frame;
   _counter = 0;

   return true;
}

bool CamTracker::update(cv::Mat frame)
{
    if (_started == false)
        return false;

    switch (_selTracker)
    {
       case STRUCK:
           _struck->Track(frame);
           break;
       case TLD:
       case MIL:
       case BOOSTING:
       case MEDIANFLOW:
           if( !_tracker->update( frame, _trackWindow ) ) {
               cout << "***ERROR! Cannot run tracker***\n";
               return false;
           }
           break;
    }

    //acumulate data for tracker utility estimation
    _counter++;

    if (_counter == 10) {
        _prevtrackWindow = _trackWindow;
       _counter = 0;
    }

    return true;
}

cv::Rect2d CamTracker::getTrackWindow ()
{
    if (_started == false)
        return cvRect(-1,-1,-1,-1);

    switch (_selTracker)
        {
           case STRUCK:
               _trackWindow = cv::Rect(_struck->GetBB().XMin(),_struck->GetBB().YMin(),_struck->GetBB().Width(),_struck->GetBB().Height());
               break;
           case TLD:
           case MIL:
           case BOOSTING:
           case MEDIANFLOW:
               break;
        }

    return _trackWindow;
}

void CamTracker::computeScore()
{
    double dt = 0;
    _score = -1;

    if (_started == true) {
       //compute descriptor
       cv::Mat desC = getCovDescriptor(_frame, _trackWindow);
       cv::Mat desP = getCovDescriptor(_prevframe, _prevtrackWindow);

       //compute covariance matrix
       cv::Mat covC, covP,tmp;
       cv::calcCovarMatrix(desC,covC,tmp,CV_COVAR_NORMAL | CV_COVAR_ROWS,CV_64F);
       cv::calcCovarMatrix(desP,covP,tmp,CV_COVAR_NORMAL | CV_COVAR_ROWS,CV_64F);

       //compute distance
       cv::Mat data = covP.inv(CV_SVD) * covC + 1e-6;
       cv::SVD svd(data);
       //cv::PCA pca( data , cv::Mat(), cv::PCA::DATA_AS_ROW);
       cv::Mat u = svd.u, w = svd.w, vt = svd.vt;

       for (int i=0; i < 5; i++)
           dt = dt + pow(log2(w.at<double>(0,i)),2);
           //dt = dt + pow(log2(pca.eigenvalues.at<double>(0,i)),2);
       dt = sqrt(dt);

       //double mean = 7, sigma = 2; //IVT
       double mean = 6, sigma = 2; //STRUCK
       //_score = 1.0/(sigma*(double)sqrt(6.28)) * exp(-0.5 * (dt-mean)/sigma *(dt-mean)/sigma );
       _score = exp(-0.5 * (dt-mean)/sigma *(dt-mean)/sigma );
       //cout << "p=" << 1.0/(sigma*(double)sqrt(6.28)) << " d=" << -0.5 * (dt-mean)/sigma *(dt-mean)/sigma << " e=" << exp(-0.5 * (dt-mean)/sigma *(dt-mean)/sigma) << endl;

       if (dt < 0.05)
           _score = 1;
    }
   //cout << "id=" << _id << " dt=" << dt << " score=" << _score << endl;
}

cv::Mat CamTracker::getCovDescriptor(cv::Mat img, cv::Rect roi)
{
    //get subimage
    assert( RECT_IN_MAT(roi, img) );
    cv::Mat subImg(img, roi);

    //compute descriptor
    cv::Mat des = cv::Mat::zeros(subImg.rows*subImg.cols, 5, CV_64F);

    for (int i=0; i < subImg.rows; i++)
      for (int j=0; j < subImg.cols; j++) {
          des.at<double>(i*subImg.cols + j,1) = i;
          des.at<double>(i*subImg.cols + j,2) = j;
          des.at<double>(i*subImg.cols + j,3) = subImg.at<cv::Vec3b>(i,j)[0];
          des.at<double>(i*subImg.cols + j,4) = subImg.at<cv::Vec3b>(i,j)[1];
          des.at<double>(i*subImg.cols + j,5) = subImg.at<cv::Vec3b>(i,j)[2];
      }
    return des;
}
