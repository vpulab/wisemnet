// *****************************************************************************
//  Copyright (C): Juan C. SanMiguel, 2015
//  Author(s): Juan C. SanMiguel
//  Developed at EECS, Queen Mary University (London)
//  This file is distributed under the terms in the attached LICENSE_2 file.  
//  If you do not find this file, copies can be found by writing to:
//  - juan.carlos.sanmiguel@eecs.qmul.ac.uk
//  - andrea.cavallaro@eecs.qmul.ac.uk                                        
// *****************************************************************************
#pragma GCC diagnostic ignored "-Wunused-function"

#ifndef __WISECAMERACAWCTRACKER_UTILS_H__
#define __WISECAMERACAWCTRACKER_UTILS_H__

#include <iostream>
#include <map>
#include <vector>

#include <opencv.hpp>
#include <opencv2/tracking.hpp>

#include "WiseCameraCAWCTrackerPkt_m.h" //application messages
#include "WiseDefinitionsTracking.h"    //structures for tracking
#include "../Trackers/struck/Tracker.h" //STRUCK algorithm & configuration
#include "WiseResourceManager.h"

using std::vector;
using std::ostream;
using namespace std;

template<typename T>
ostream& operator<< (ostream& out, const vector<T>& v) {
    out << "[";
    size_t last = v.size() - 1;
    for(size_t i = 0; i < v.size(); ++i) {
        out << v[i];
        if (i != last)
            out << ", ";
    }
    out << "]";
    return out;
}

static void print(std::ostream& out, cv::Mat mat, int prec)
{
    out << "[";
    for(int i=0; i<mat.size().height; i++)  {
        for(int j=0; j<mat.size().width; j++) {
            out << setprecision(prec) << mat.at<double>(i,j);

            if(!(i == mat.size().height-1 && j == mat.size().width-1))
                out << ",";
        }
    }
    out << "]" << endl;
}

namespace CAWC
{
    typedef enum {
       STRUCK      = 0, //!< STRUCK tracker
       TLD         = 1, //!< TLD tracker
       MIL         = 2, //!< MIL tracker
       BOOSTING    = 3, //!< BOOSTING tracker
       MEDIANFLOW  = 4, //!< MEDIANFLOW tracker - experimental (provides errors)
    } tracker_type_t;

    typedef enum {
         INACTIVE             =-1,
         UTILITY_SHARING      = 0,
         MANAGER_SELECTION    = 1,
         NEGOTIATION          = 2,
         COLLABORATION        = 3,
    } coalition_status_t;

    static map<int,std::string> create_pkt_str() {

         std::map<int,std::string> m;
         m.insert(std::make_pair(CAWC_UTILITY, "CAWC_UTILITY"));
         m.insert(std::make_pair(CAWC_NEWMANAGER, "CAWC_NEWMANAGER"));
         m.insert(std::make_pair(CAWC_NEWMANAGER_ACK, "CAWC_NEWMANAGER_ACK"));
         m.insert(std::make_pair(CAWC_NEWMANAGER_ACK_SEND, "CAWC_NEWMANAGER_ACK_SEND"));
         m.insert(std::make_pair(CAWC_NEWMANAGER_SEND, "CAWC_NEWMANAGER_SEND"));
         m.insert(std::make_pair(CAWC_NEGOTIATION_JOIN, "CAWC_NEGOTIATION_JOIN"));
         m.insert(std::make_pair(CAWC_NEGOTIATION_REPLY, "CAWC_NEGOTIATION_REPLY"));
         m.insert(std::make_pair(CAWC_COLLABORATION_REQUEST, "CAWC_COLLABORATION_REQUEST"));
         m.insert(std::make_pair(CAWC_COLLABORATION_DATA, "CAWC_COLLABORATION_DATA"));
         m.insert(std::make_pair(CAWC_COLLABORATION_END, "CAWC_COLLABORATION_END"));
         return m;
     }
    static map<int,std::string> CAWCpkt_str  = CAWC::create_pkt_str(); //strings for each packet type

      static map<int,int> create_pkt_size() {

         std::map<int,int> m;

         //CAWC_UTILITY pkt --> message type(int) + frame number(int) + camera ID(int) + utility(double) + battery(double) + load(double) + priority(double)
         m.insert(std::make_pair(CAWC_UTILITY, 3*WISE_BYTES_INT + 4*WISE_BYTES_DOUBLE)); //44 bytes

         //CAWC_NEWMANAGER pkt --> message type(int) + frame number(int) + camera ID(int) + x(4*double) + P(16*double)
         m.insert(std::make_pair(CAWC_NEWMANAGER, 3*WISE_BYTES_INT)); //12 bytes

         //CAWC_NEWMANAGER_ACK pkt --> message type(int) + frame number(int) + ACK(char)
         m.insert(std::make_pair(CAWC_NEWMANAGER_ACK, 2*WISE_BYTES_INT + WISE_BYTES_UINT8)); //9 bytes

         //CAWC_NEWMANAGER_ACK_SEND pkt --> message type(int) + frame number(int) + ACK(char)
          m.insert(std::make_pair(CAWC_NEWMANAGER_ACK_SEND, 2*WISE_BYTES_INT + WISE_BYTES_UINT8)); //9 bytes

         //CAWC_NEWMANAGER_SEND_EST pkt --> message type(int) + frame number(int) + camera ID(int) + x(4*double) + P(16*double)
         m.insert(std::make_pair(CAWC_NEWMANAGER_SEND, 3*WISE_BYTES_INT+20*WISE_BYTES_DOUBLE)); //172 bytes

         //CAWC_NEGOTIATION_JOIN pkt --> message type(int) + frame number(int)
         m.insert(std::make_pair(CAWC_NEGOTIATION_JOIN, 2*WISE_BYTES_INT)); //8 bytes

         //CAWC_NEGOTIATION_REPLY pkt --> message type(int) + frame number(int) + data(char)
         m.insert(std::make_pair(CAWC_NEGOTIATION_REPLY, 2*WISE_BYTES_INT + WISE_BYTES_UINT8)); //9 bytes

         //CAWC_COLLABORATION_REQUEST pkt --> message type(int) + frame number(int) + data(char)
         m.insert(std::make_pair(CAWC_COLLABORATION_REQUEST, 2*WISE_BYTES_INT + WISE_BYTES_UINT8));//9 bytes

         //CAWC_COLLABORATION_DATA pkt --> message type(int) + frame number(int) + measurement (2*double) + covariance (4*double) + measurement matrix (8*double)
         m.insert(std::make_pair(CAWC_COLLABORATION_DATA, 2*WISE_BYTES_INT+12*WISE_BYTES_DOUBLE)); //104 bytes

         //CAWC_COLLABORATION_DATA pkt --> message type(int) + frame number(int)
         m.insert(std::make_pair(CAWC_COLLABORATION_END, 2*WISE_BYTES_INT)); //8bytes
         return m;
     }
     static map<int,int> CAWCpkt_size = CAWC::create_pkt_size(); //size for each packet type

     static map<int,std::string> create_tracker_str() {

         std::map<int,std::string> m;
         m.insert(std::make_pair(STRUCK, "STRUCK"));
         m.insert(std::make_pair(TLD, "TLD"));
         m.insert(std::make_pair(MIL, "MIL"));
         m.insert(std::make_pair(BOOSTING, "BOOSTING"));
         m.insert(std::make_pair(MEDIANFLOW, "MEDIANFLOW"));
         return m;
     }

      struct target_initialization_t  {
          std::string filenameGT;
          int id;
          int frame;
          int Xc;
          int Yc;
          int width;
          int height;

          double resize;
      };

      struct IF_filter_t  {
          unsigned int dimS; //!< Dimension of the state vector
          unsigned int dimM; //!< Dimension of the measurement vector

          cv::Mat x;      //!< posterior estimate
          cv::Mat x_;     //!< prior estimate

          cv::Mat J;      //!< posterior information matrix (inverse of covariance)
          cv::Mat J_;     //!< prior information matrix (inverse of covariance)
          cv::Mat P;      //!< priori error estimate covariance matrix P'(k)): P'(k)=A*P(k-1)*At + Q)
          cv::Mat P_;      //!< priori error estimate covariance matrix P'(k)): P'(k)=A*P(k-1)*At + Q)
          cv::Mat Pinv;

          cv::Mat u;      //!< ??
          cv::Mat U;      //!< ??

          cv::Mat v;      //!< ??
          cv::Mat V;      //!< ??

          cv::Mat A, At;  //!< transition matrix (normal and transpose)
          cv::Mat H, Ht;  //!< measurement matrix (normal and transpose)

          cv::Mat Q;      //!< process covariance matrix (for transition)
          cv::Mat Rinv;   //!< measurement covariance matrix (for measurement)
          cv::Mat eyeS;   //!< diagonal matrix dimS-by-dimS

          cv::Mat z;
      };

   struct neigbor_data_t {
             int step_counter;

             double utility;
             double battery_level;
             double load_level;
             double priority;

             int camID;
             int nodeID;

             cv::Mat z;      //!<
             cv::Mat Rinv;      //!<
             cv::Mat Ht;      //!<
             cv::Mat H;      //!<

             state_t_4D state;   //!< states received from other nodes
             bool    rcv_state;
             bool    rcv_data_utility;      //!< status of the data received by other nodes: received(true) or not received(false)
             bool    rcv_ack_manager;
      };

       static neigbor_data_t init_neigb_data(int _nodeID, int _camID, int _step_counter, double _utility,
                                               double _battery_level, double _load_level, double _priority) {
           neigbor_data_t nb;
           nb.step_counter = _step_counter;
           nb.nodeID = _nodeID;
           nb.camID = _camID;
           nb.utility= _utility;
           nb.battery_level = _battery_level;
           nb.load_level = _load_level;
           nb.priority = _priority;

           nb.rcv_data_utility = false;
           nb.rcv_state = false;
           nb.rcv_ack_manager = false;

           return nb;
      }

      struct coalition_data_t {
             coalition_status_t state;

             IF_filter_t IF;

             bool initManager;
             int managerID;

             std::vector<int> cams;
             std::vector<int> nego;
             double u;
             double mcost;
             double beta;

             double est_energy2operate;

             coalition_data_t& operator =(const coalition_data_t& m) {
                 state = m.state;
                 initManager = m.initManager;
                 managerID = m.managerID;
                 nego = m.nego;
                 cams = m.cams;
                 u = m.u;
                 mcost = m.mcost;
                 beta = m.beta;
                 IF = m.IF;
                 return *this;
             }
      };
      struct coalition_log_t {
          std::vector<int> step_count, manager;
          std::vector< std::vector<int> > cams, nego;
          std::vector<cv::Mat> u,b,l,x,P,rx,tx;
          cv::Mat rxdata;
          cv::Mat txdata;
          double beta;
      };

   static IF_filter_t create_IF() {
       IF_filter_t IF;

       int dimS = 4;
       int dimM = 2;
       double measNoiseCov = 10;
       double procNoiseCov = 10;

       IF.eyeS = cv::Mat::eye(dimS, dimS, CV_64F);
       IF.dimS = dimS;
       IF.dimM = dimM;

       //prior, posterior and covariance of the state
       IF.x_ = cv::Mat::zeros(dimS, 1, CV_64F); //prior state
       IF.x  = cv::Mat::zeros(dimS, 1, CV_64F); //posterior state
       IF.P_ = (cv::Mat_<double>(dimS, dimS) << 5,0,0,0, 0,5,0,0, 0,0,2,0, 0,0,0,2); //prior state covariance
       IF.P  = cv::Mat::zeros(dimS, dimS, CV_64F); //posterior state
       IF.Pinv  = cv::Mat::zeros(dimS, dimS, CV_64F);
       IF.Pinv  = IF.P.inv(cv::DECOMP_SVD); //prior state covariance

       //transition matrix
       IF.A  = (cv::Mat_<double>(dimS, dimS) << 1,0,1,0, 0,1,0,1, 0,0,1,0, 0,0,0,1);
       IF.At = cv::Mat::zeros(dimS, dimS, CV_64F);
       cv::transpose(IF.A, IF.At);

       //measurement matrix
       IF.H    = (cv::Mat_<double>(dimM, dimS) << 1,0,0,0, 0,1,0,0);
       IF.Ht = cv::Mat::zeros(dimS, dimM, CV_64F);
       cv::transpose(IF.H, IF.Ht);

       //measurement covariance
       IF.Rinv = measNoiseCov * cv::Mat::eye(dimM, dimM, CV_64F);
       IF.Rinv = 1.0 * IF.Rinv.inv(cv::DECOMP_SVD);

       //process covariance
       IF.Q  = procNoiseCov * (cv::Mat_<double>(dimS, dimS) << 1,0,0.1,0, 0,1,0,0.1, 0,0,0.1,0, 0,0,0,0.1);

       //information-based variables
       IF.J_ = cv::Mat::zeros(dimS, dimS, CV_64F); //prior information matrix
       IF.J_ = IF.eyeS/IF.P;
       IF.J  = cv::Mat::zeros(dimS, dimS, CV_64F); //posterior information matrix
       IF.v  = cv::Mat::zeros(dimS, 1, CV_64F); //??
       IF.V  = cv::Mat::zeros(dimS, dimS, CV_64F); //??
       IF.u  = cv::Mat::zeros(dimS, 1, CV_64F);    //information vector
       IF.U  = cv::Mat::zeros(dimS, dimS, CV_64F); //information matrix

       IF.z  = cv::Mat::zeros(dimM, 1, CV_64F);
       //LOGGER << "ICF CONFIG" << endl << "A=" << endl << IF.A << endl << "H=" << endl << IF.H
       //        << endl << "P=" << endl << IF.P << endl << "Pinv=" << endl << IF.Pinv << endl
       //        << endl << "Rinv=" << endl << IF.Rinv << endl << "Q=" << endl << IF.Q << endl;
       return IF;
   }

   static coalition_data_t init_coalition_data(int managerID, double utility, double marginal_cost) {

       coalition_data_t coa;
       coa.managerID = managerID;
       coa.initManager = false;
       coa.state = INACTIVE;

       coa.cams.clear();
       coa.u = utility;
       coa.mcost = marginal_cost;

       coa.IF = create_IF();
       coa.beta = 0.5;
       coa.est_energy2operate = 10;

       return coa;
   }

    static WiseCameraCAWCTrackerPkt* create_utility_pkt(int self, int camID,double score,double batlevel,double load,double priority) {

          WiseCameraCAWCTrackerPkt *pkt = new WiseCameraCAWCTrackerPkt("CAWC_UTILITY", APPLICATION_PACKET);
          pkt->setPktType(CAWC_UTILITY);
          pkt->setNodeID(self);
          pkt->setCamID(camID);
          pkt->setUtility(score);
          pkt->setBattery_level(batlevel);
          pkt->setLoad_level(load); //only one target is the current load
          pkt->setPriority(priority); //equal priority
          pkt->setByteLength(CAWCpkt_size[CAWC_UTILITY]);
          return pkt;
        }

    static WiseCameraCAWCTrackerPkt* create_newMan_pkt(int self, int camID, int newManager, cv::Mat x, cv::Mat P) {

           WiseCameraCAWCTrackerPkt *pkt = new WiseCameraCAWCTrackerPkt("CAWC_NEWMANAGER", APPLICATION_PACKET);
           pkt->setPktType(CAWC_NEWMANAGER);
           pkt->setNodeID(self);
           pkt->setCamID(camID);
           pkt->setNewManager(newManager);
           pkt->setX(x);
           pkt->setP(P);
           pkt->setByteLength(CAWCpkt_size[CAWC_NEWMANAGER]);
           return pkt;
    }

    static WiseCameraCAWCTrackerPkt* create_empty_pkt(WiseCAWCPacketType type,std::string str, int nodeID,int camID) {

        WiseCameraCAWCTrackerPkt *pkt = new WiseCameraCAWCTrackerPkt(str.c_str(), APPLICATION_PACKET);
        pkt->setPktType(type);
        pkt->setNodeID(nodeID);
        pkt->setCamID(camID);
        pkt->setByteLength(CAWCpkt_size[type]);
        return pkt;
    }

    class CamTracker
    {
        private:
            tracker_type_t _selTracker; //!< flag for the selected tracker
            bool _started;              //!< flag to indicate the tracker is running
            cv::Rect2d _trackWindow;    //!< target state estimation
            cv::Mat _frame;    //!< target state estimation
            cv::Rect2d _prevtrackWindow;    //!< target state estimation
            cv::Mat _prevframe;    //!< target state estimation
            int _counter;
            double _score;

            cv::Ptr<cv::Tracker> _tracker; //OpenCV based trackers
            Tracker* _struck; //STRUCK algorithm
            Config* _conf; //STRUCK configuration

            std::map<int,std::string> _trackers_str;

            int _id;

        public:
            CamTracker(int id=0);
            ~CamTracker();

            void setId(int id) {this->_id = id;};
            int getId() {return this->_id;};

            bool selectTracker(CAWC::tracker_type_t type = STRUCK);
            bool initialize(cv::Mat frame, target_initialization_t);
            bool update(cv::Mat frame);

            const char *getTrackerName() {return _trackers_str[_selTracker].c_str();};
            bool getStarted () {return _started;};
            cv::Rect2d getTrackWindow ();

            void computeScore();
            double getScore() {return this->_score;};

            cv::Mat getCovDescriptor(cv::Mat img, cv::Rect roi);
    };
}
#endif // __WISECAMERACAWCTRACKER_UTILS_H__
