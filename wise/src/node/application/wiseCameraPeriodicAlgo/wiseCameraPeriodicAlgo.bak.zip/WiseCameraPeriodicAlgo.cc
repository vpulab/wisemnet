// *****************************************************************************
//  Copyright (C): Juan C. SanMiguel, 2014
//  Author(s): Juan C. SanMiguel
//  Developed at the:                                                         
//  - VPU LAB, Universidad Autonoma de Madrid (UAM)
//  - School of Elec Eng and Computer Science, Queen Mary University (London) 
//  This file is distributed under the terms in the attached LICENSE_2 file.  
//  If you do not find this file, copies can be found by writing to:          
//  - juancarlos.sanmiguel@uam.es
//  - andrea.cavallaro@eecs.qmul.ac.uk                                        
// *****************************************************************************

#include <fstream>
#include "WiseCameraPeriodicAlgo.h"
#include "WiseCameraPeriodicAlgoPacket_m.h"

#define perr_app(m) opp_error("\n[Application]:\n "m)

// For logging all the module information into baseline Castalia trace
#define BASE_TRACE trace() << "WISEALGO: "

/*! Initialization of WiseCameraPeriodicAlgo class and getting of user-defined variables in omnetpp.ini file*/
void WiseCameraPeriodicAlgo::startup()
{
    BASE_TRACE << "STARTUP";

    //initialize WiseCameraApplication class
	WiseCameraApplication::startup();

	//read user-defined variables in omnetpp.ini
	_network_ready = false;//network is not ready until the comms&vision graphs are discovered
	_sampling_time = par("sampling_time");
	_sample_lifetime = par("sample_lifetime");
	if (_sample_lifetime < 0 || _sample_lifetime > _sampling_time)
		_sample_lifetime = _sampling_time;
	_sampling_end2start_time = _sampling_time - _sample_lifetime;

	//configure resource manager
    if (getParentModule()->findSubmodule("ResourceManager") != -1)
        resMgrModule = check_and_cast <WiseResourceManager*>(getParentModule()->getSubmodule("ResourceManager"));
     else
        perr_app("Error in getting a valid reference to ResourceManager for direct method calls.");

    _samplingRate = 1/_sampling_time;//samples(frames) per second
    resMgrModule->setSamplingRate(1/_sampling_time); //frames per second

    //variables to be computed upon receival of data from the sensing module
    _frameRate = -1;
    _resize=-1;

    //initialize buffer for sensing data (ie frame)
    _data_valid = false;
    _frame = cv::Mat::zeros(300, 300,CV_32F);

    //initialize superclass
    at_startup();

    //set the initial status to check for network being ready
    _fsm_state = FSM_WAIT_GRAPHS;
    setTimer(ALARM_WAIT_GRAPH, 0);

	BASE_TRACE << "sampling_time=" << _sampling_time << " sample_lifetime=" << _sample_lifetime << " sampling_end2start_time=" << _sampling_end2start_time;
}

/*! Specific operations to perform when finishing the tracker*/
void WiseCameraPeriodicAlgo::finishSpecific()
{
	WiseCameraApplication::finishSpecific();
}

/*!
 * Callback function for responding to alarms generated for sync the tracker operations
 * @param[in]  index  Type of alarm
 */
void WiseCameraPeriodicAlgo::timerFiredCallback(int index)
{
    switch (index)
    {
        case ALARM_WAIT_GRAPH:
            BASE_TRACE << "ALARM_WAIT_GRAPH";
            fsm_algo(INVALID);
            break;
        case ALARM_SENSOR_SAMPLE:
            BASE_TRACE << "ALARM_SENSOR_SAMPLE";
            if (isSink == false)
                requestSensorReading();
            break;
        case ALARM_END_SAMPLE_PERIOD:
            BASE_TRACE << "ALARM_END_SAMPLE_PERIOD";
            fsm_algo(INVALID);
            break;
        default:
            at_timer_fired(index);
    }
}

/*!
 * Function in charge of managing the states of the fsm (updating and performing the desired operations)
 * @param[in]  t  Type of sample received by the tracker from the SensorManager (used depending on the current state)
 * @param[in]  restart  Boolean value to restart the tracker fsm and for going to the initial state = FSM_INIT.
 */
void WiseCameraPeriodicAlgo::fsm_algo(sample_type_t t, bool restart)
{
    double e1,e2,time;

	if (restart){
	    BASE_TRACE << "FSM : RESTART";
		_fsm_state = FSM_INIT;
	}

	switch(_fsm_state)
	{
	    //wait for graph completion
	    case FSM_WAIT_GRAPHS:
            BASE_TRACE << "FSM : FSM_WAIT_GRAPHS";

            if (check_graph_completion()) {
                BASE_TRACE << "BOTH_GRAPHS_COMPLETED (network_ready=true,  max_neigbourgFOV=" << max_NeighboursFOV << ") Sending reset to network...";
                _fsm_state = FSM_INIT;

                //send reset message to all network nodes (ie sync of sampling instants)
                WiseCameraPeriodicAlgoPacket *pkt = new WiseCameraPeriodicAlgoPacket("CONTROL:reset", APPLICATION_PACKET);
                pkt->setType(WISE_NEIGHBOUR_RESET);
                toNetworkLayer(pkt, BROADCAST_NETWORK_ADDRESS);
                //sendDirectApplicationMessage(pkt, BROADCAST_NETWORK_ADDRESS); //No direct as management of DirectApplicationMessage is in the superclass
                fsm_algo(INVALID); //restart the FSM
            }
            else
                setTimer(ALARM_WAIT_GRAPH, 1);//both graphs are not ready (wait 1sec and repeat checking)
	        break;
	    case FSM_INIT:
            BASE_TRACE << "FSM : INIT";
            _step_counter = 0;
            at_init();
            detections.clear();
            setTimer(ALARM_SENSOR_SAMPLE, 0);
            _fsm_state = FSM_WAIT_FIRST_SAMPLE;
            break;
        case FSM_WAIT_FIRST_SAMPLE:
            BASE_TRACE << "FSM : WAIT_FIRST_SAMPLE";
            if (t == DETECTIONS)
                make_measurements(detections);

            e1 = cv::getTickCount();
            at_first_sample();
            e2 = cv::getTickCount();
            time = (e2 - e1)/ cv::getTickFrequency();
            resMgrModule->computeEnergyPro(time);

            setTimer(ALARM_END_SAMPLE_PERIOD, _sample_lifetime);
            _fsm_state = FSM_WAIT_END_FIRST_SAMPLE;
            break;
        case FSM_WAIT_END_FIRST_SAMPLE:
            BASE_TRACE << "FSM : WAIT_END_FIRST_SAMPLE";
            at_end_first_sample();
            detections.clear();
            setTimer(ALARM_SENSOR_SAMPLE, _sampling_end2start_time);
            _fsm_state = FSM_WAIT_SAMPLE;
            break;
        case FSM_WAIT_SAMPLE:
            BASE_TRACE << "FSM : WAIT_SAMPLE (step = " << _step_counter << ")";
            if (t == DETECTIONS)
                make_measurements(detections);
            e1 = cv::getTickCount();
            at_sample();
            cv::waitKey(1);
            e2 = cv::getTickCount();
            time = (e2 - e1)/ cv::getTickFrequency();
            resMgrModule->computeEnergyPro(time);
            setTimer(ALARM_END_SAMPLE_PERIOD, _sample_lifetime);
            _fsm_state = FSM_WAIT_END_SAMPLE;
            break;
        case FSM_WAIT_END_SAMPLE:
            BASE_TRACE << "FSM : WAIT_END_SAMPLE (step = " << _step_counter << ")";
            at_end_sample(); //ADD ENERGY COMPUTATION!!!
            detections.clear();
            setTimer(ALARM_SENSOR_SAMPLE, _sampling_end2start_time);
            _fsm_state = FSM_WAIT_SAMPLE;
            break;
	}
}

/*!
 * Function to check the completion of the discovery process for the communications and vision graph for all nodes
 */
bool WiseCameraPeriodicAlgo::check_graph_completion()
{
    //check for all the network nodes if they are completed
    for (int i = 0; i < n_nodes; i++) {
        cModule *m = getParentModule()->getParentModule(); // m=SN
        m = m->getSubmodule("node", i)->getSubmodule("Application");
        WiseCameraPeriodicAlgo *c = check_and_cast<WiseCameraPeriodicAlgo*>(m);

        if (c->neighbourDiscoverCOMCompleted == false || c->neighbourDiscoverFOVCompleted == false)
            return false;
    }

    _network_ready = true;//both graphs ready, indicate network is ready

    //compute the maximum number of neighbors in the network
    max_NeighboursFOV = 0;
    for (int i = 0; i < n_nodes; i++) {
            cModule *m = getParentModule()->getParentModule(); // m=SN
            m = m->getSubmodule("node", i)->getSubmodule("Application");
            WiseCameraPeriodicAlgo *c = check_and_cast<WiseCameraPeriodicAlgo*>(m);

            if (c->overlapping_fov_cameras.size() > max_NeighboursFOV);
                max_NeighboursFOV = c->overlapping_fov_cameras.size();
    }

    //if we arrive here, it is because all graph discovery stages are completed
    return true;
}

/*!
 * Function to process packets coming from the network
 * @param[in]  p  Packet
 * @param[in]  src string defining the source node
 * @param[in]  rssi ???
 * @param[in]  lqi ???
 */
void WiseCameraPeriodicAlgo::fromNetworkLayer(WiseApplicationPacket *pkt, const char *src, double rssi, double lqi)
{
    //avoid further data processing if node is not ready
    if (!_network_ready){
       BASE_TRACE << "Received pkt and node is not ready";
       return;
    }

    //Reinitialization request
    if (pkt->getTypeNeighbour() == WISE_NEIGHBOUR_RESET){

        //reinitialize only if we have not initialized yet in the same step
        if (_step_counter != 0){
            _fsm_state = FSM_INIT;
            fsm_algo(INVALID);
            BASE_TRACE << "Received init request from=" << string(src) << " -> Ready (YES)";
        }
        else
            BASE_TRACE << "Received init request from=" << string(src) << " -> Already initiated (NO)";

        return;
    }

    //process packet from network
    ApplicationInteractionControl_type ctl = pkt->getApplicationInteractionControl();
    double l = SIMTIME_DBL(simTime() - ctl.timestamp);
    BASE_TRACE << "RX packet:" " from=" << string(src) << " rssi=" << rssi << " lqi=" << lqi << " app2app_delay=" << l;
    process_network_message(pkt);//to be defined in the superclass

    //Energy consumption
    resMgrModule->computeEnergyCrx(pkt->getByteLength());
}

/*!
 * Function to process the readings/detections obtained by the SensorManager. Currently it copies the list of detections provided
 *  into the local list of the tracker.
 *
 * @param[in] m Message received with all the detections
 */
void WiseCameraPeriodicAlgo::handleSensorReading(WiseCameraMessage *m)
{
    string type = m->getCameraSampleType();
    sample_type_t t;

    if (type == "WiseCameraDetections") {
       t = DETECTIONS;
       const WiseCameraDetectionsMessage *s = check_and_cast<const WiseCameraDetectionsMessage*>(m);

       unsigned len = s->getDetectionsArraySize();
       for (unsigned i = 0; i < len; i++) {
           WiseTargetDetection d = s->getDetections(i);
           detections.push_back(d);
           if (!d.valid)
               continue;
           BASE_TRACE << "Detection: BB(" << d.bb_x_tl << " " << d.bb_y_tl << " " << d.bb_x_br << " " << d.bb_y_br << ") extBB(" << d.ext_bb_x_tl << " " << d.ext_bb_y_tl << " " << d.ext_bb_x_br << " " << d.ext_bb_y_br << ") trueBB(" << d.true_bb_x_tl << " " << d.true_bb_y_tl << " " << d.true_bb_x_br << " " << d.true_bb_y_br << ")";/**/;
       }
    }

    if (type == "WiseCameraVideo") {
            t = FRAMES;
            const WiseCameraVideoMessage *s = check_and_cast<const WiseCameraVideoMessage*>(m);
            _curFrame = s->getCurFrame();
            _frame = s->getFrame();
            _frameRate = s->getFrameRate();
            _resize = s->getResize();

            resMgrModule->setFrameRate(_frameRate);
            resMgrModule->setFrameSize(_frame.cols*_frame.rows*_frame.channels());
    }
    if (type != "WiseCameraVideo" && type != "WiseCameraDetections")
        opp_error("\n[WiseCameraPeriodicAlgo]: WiseCameraMessage is of invalid type");

    fsm_algo(t);

    //Update energy consumption
    if (type == "WiseCameraVideo") {
        resMgrModule->computeEnergySen(_frame.cols*_frame.rows*_frame.channels(),_samplingRate);
    }
}

/*!
 * Function to send a message to a specific neighbors using the communication graph.
 *
 * @param[in] m Message to be sent
 * @param[in] dst String indicating the ID of the neighbor
 */
void WiseCameraPeriodicAlgo::send_message(WiseApplicationPacket *m, const std::string &dst)
{
    map<string, bool>::const_iterator n = connectivity_map_comms.find(dst);
    if (n == connectivity_map_comms.end())
        return; // overlapping fov but NOT a neighbour
    // This messages will trigger the event (simulation) AFTER other messages pending at the SAME sim_time
    // with prio < 10 (the default prio=0)
    m->setSchedulingPriority(10);
    toNetworkLayer(m, dst.c_str()); // Unicast send

    //Energy consumption
    resMgrModule->computeEnergyCtx(m->getByteLength());
}

/*!
 * Function to send a broadcast message to all neighbors so communication graph is used (ie, maximum coverage of radio signal).
 *
 * @param[in] m Message to be sent
 */
void WiseCameraPeriodicAlgo::send_message(WiseApplicationPacket *m)
{
    //JCS:originally not commented
    //map<string, bool>::const_iterator n = connectivity_map_comms.begin();

    // This messages will trigger the event (simulation) AFTER other pending messages that at the SAME
    // sim_time have prio < 10 (the default prio=0)
    m->setSchedulingPriority(10);
    // Broadcast send
    toNetworkLayer(m->dup(), "-1");

    //Energy consumption
    resMgrModule->computeEnergyCtx(m->getByteLength());

    delete m;
}

/*!
 * Function to send a message to neighbors in the communication graph.
 *
 * @param[in] m Message to be sent
 */
int WiseCameraPeriodicAlgo::send_messageNeighboursCOM(WiseApplicationPacket *m)
{
    int nNodes = 0;
    if (neighboursCOM.size() == 0)
           return -1;//no neighbors

    m->setTypeNeighbour(WISE_NEIGHBOUR_COM);

    map<string, bool>::const_iterator n;
    for (n = connectivity_map_comms.begin(); n != connectivity_map_comms.end(); ++n)
        if ((*n).second == true)
           if (atoi((*n).first.c_str()) != this->self)
           {
               nNodes++;
               BASE_TRACE << " SEND PKT to COM neighbor node=" << (*n).first.c_str() << endl;
               toNetworkLayer(m->dup(), (*n).first.c_str());
           }

    //Energy consumption
    resMgrModule->computeEnergyCtx(nNodes*m->getByteLength());

    delete m;
    return 1;
}

/*!
 * Function to send a message to neighbors in the vision graph.
 *
 * @param[in] m Message to be sent
 */
int WiseCameraPeriodicAlgo::send_messageNeighboursFOV(WiseApplicationPacket *m)
{
    int nNodes = 0;

    if (overlapping_fov_cameras.size() == 0)
        return -1;//no neighbors

    m->setTypeNeighbour(WISE_NEIGHBOUR_FOV);

    map<string, bool>::const_iterator n;
    for (n = connectivity_map_fov.begin(); n != connectivity_map_fov.end(); ++n)
        if ((*n).second == true)
           if (atoi((*n).first.c_str()) != this->self)
           {
               nNodes++;
               BASE_TRACE << "SEND PKT to neigbFOV node=" << (*n).first.c_str();
               toNetworkLayer(m->dup(), (*n).first.c_str());
           }

    //Energy consumption
    resMgrModule->computeEnergyCtx(nNodes*m->getByteLength());

    delete m;
    return 1;
}
