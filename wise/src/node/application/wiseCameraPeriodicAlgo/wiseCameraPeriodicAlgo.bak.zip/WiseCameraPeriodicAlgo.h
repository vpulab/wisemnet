// *****************************************************************************
//  Copyright (C): Christian Nastasi, 2011                                    
//  Author(s): Christian Nastasi                                              
//  Developed at the:                                                         
//  - Retis LAB, TeCIP Institute, Scuola Superiore Sant'Anna (Pisa)           
//  - School of Elec Eng and Computer Science, Queen Mary University (London) 
//  This file is distributed under the terms in the attached LICENSE_2 file.  
//  If you do not find this file, copies can be found by writing to:          
//  - c.nastasi@sssup.it                                                      
//  - nastasichr@gmail.com                                                    
//  - andrea.cavallaro@eecs.qmul.ac.uk                                        
// *****************************************************************************

#ifndef __WiseCameraPeriodicAlgo_H__
#define __WiseCameraPeriodicAlgo_H__

#include <vector>
#include <map>
#include "WiseCameraApplication.h"
#include "WiseCameraDetectionsMessage_m.h"
#include "WiseCameraVideoMessage_m.h"
#include "WiseCameraPeriodicAlgoPacket_m.h"
#include "WiseDefinitionsTracking.h"

// Alarms handled by the periodic algorithm
const int ALARM_WAIT_GRAPH        = 0; //!< Periodic alarm to check completion of vision&comms graphs discovery
const int ALARM_SENSOR_SAMPLE     = 1; //!< Periodic alarm to request a new sample to SensorManager
const int ALARM_END_SAMPLE_PERIOD = 2; //!< Periodic alarm to indicate end of lifetime of sample (and prepare the algorithm for next capture)

/*! \class WiseCameraPeriodicAlgo
 *  \brief This class implements the template for a periodic execution of three tasks: sensing, processing & communication.
 *
 *   - At initialization, the topology for vision and comms can be set via the NED parameter 'neighbourDiscoverCOM' & 'neighbourDiscoverFOV'
 *   - A finite-state-machine implements the transitions between the three tasks (sensing, processing & communication)
 *   - The frequency for acquiring new samples (eg, frames) is managed by the NED parameter 'sampling_time'
 *   - The consumption of each tasks is considered by the WiseResourceManager module.
 *
 */
class WiseCameraPeriodicAlgo : public WiseCameraApplication {

private:

   /*! \enum sample_type_t
    *  Describes whether the samples obtained by the node are valid or not.
    */
   typedef enum {
       INVALID     = 0, //!< Samples/measurements are not valid
       DETECTIONS  = 1, //!< Samples/measurements are valid and correspond to detections
       FRAMES      = 2, //!< Samples/measurements are valid and correspond to video frames
   } sample_type_t;

   /*! \enum fsm_algorithm_state_t
    *  Describes the actions or states of algorithm to periodically analyze frames/data.
    */
   typedef enum {
           FSM_INIT                    = 0, //!< state for algorithm initialization
           FSM_WAIT_GRAPHS             = 1, //!< state for waiting until graphs (vision & comms) are discovered in the network
           FSM_WAIT_FIRST_SAMPLE       = 2, //!< state for waiting until the 1st sample is captured
           FSM_WAIT_END_FIRST_SAMPLE   = 3, //!< state to indicate that the lifetime of 1st sample has expired and a new sample will be captured
           FSM_WAIT_SAMPLE             = 4, //!< state for waiting until the >1st sample is captured
           FSM_WAIT_END_SAMPLE         = 5, //!< state to indicate that the lifetime of >1st sample has expired and a new sample will be captured
   } fsm_algo_state_t;

protected:
	double _sampling_time;                        //!< frequency to get new samples (in secs) from physical process (through SensorDeviceManager)
	unsigned long _step_counter;        //!< counter for the number of times the data is analyzed by the algorithm

	bool _data_valid;
	bool _network_ready;                          //!< Flag to indicate that comms and fov graphs of the network are computed

	std::vector<WiseTargetDetection> detections;  //!< List of ordered detections/measurements/ground-truth. If a target is not within the FOV, no measurement is provided (WiseTargetDetection.valid=false)

    int _curFrame;
    cv::Mat _frame;
    double _frameRate,_samplingRate,_resize;

private:
	fsm_algo_state_t _fsm_state;      //!< FSM that defines the current state of the algorithm
	double _sample_lifetime;         //!< Lifetime in secs of the captured samples
	double _sampling_end2start_time; //!< Time to start next sampling stage after "sample_lifetime" expired

protected:
	void startup();
	void finishSpecific();
	void fromNetworkLayer(WiseApplicationPacket *, const char *, double, double);
	void handleSensorReading(WiseCameraMessage *);
	void timerFiredCallback(int index);

	void send_message(WiseApplicationPacket*);
	void send_message(WiseApplicationPacket*, const std::string&);

	int send_messageNeighboursCOM(WiseApplicationPacket*);
    int send_messageNeighboursFOV(WiseApplicationPacket*);

    //Functions to be defined in implemented superclass (algorithms)
	virtual void at_startup() = 0 ;                     //!< Init internal variables. To define in superclass for each specific algorithm (mandatory)
	virtual void at_timer_fired(int index) = 0;        //!< Response to alarms generated by specific algorithm. To define in superclass (optional)
	virtual void at_init() = 0;                //!< Init resources. To define in superclass for each specific algorithm (mandatory)
	virtual void at_first_sample() = 0;       //!< Operations at 1st example. To define in superclass for each specific algorithm (mandatory)
	virtual void at_end_first_sample() = 0;  //!< Operations at the end of 1st example. To define in superclass for each specific algorithm (mandatory)
	virtual void at_sample() = 0;              //!< Operations at the >1st example. To define in superclass for each specific algorithm (mandatory)
	virtual void at_end_sample() = 0;         //!< Operations at the end of >1st example. To define in superclass for each specific algorithm (mandatory)
	virtual void process_network_message(WiseApplicationPacket *m) = 0 ; //!< Processing of packets received from network. To define in superclass for each specific algorithm (mandatory)
	virtual void make_measurements(const std::vector<WiseTargetDetection>&) = 0 ; //!< Conversion of camera detections into ordered lists of measurements for tracking. To define in superclass for each specific algorithm (mandatory)

private:
	void fsm_algo(sample_type_t t, bool restart = false); //!< Logic for jumping between the states of the algorithm
	bool check_graph_completion(); //!< Checks whether all network nodes have completed the discovery of the COM and FOV graphs
};
#endif // __WiseCameraPeriodicAlgo_H__
