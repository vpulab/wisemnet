//
// Generated file, do not edit! Created by nedtool 4.6 from wise/src/node/application/wiseCameraKCF/WiseCameraKCFMsg_v2.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "WiseCameraKCFMsg_v2_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

EXECUTE_ON_STARTUP(
    cEnum *e = cEnum::find("WiseKCFCPacketType");
    if (!e) enums.getInstance()->add(e = new cEnum("WiseKCFCPacketType"));
    e->insert(KCF_COLLABORATION_DATA1, "KCF_COLLABORATION_DATA1");
    e->insert(KCF_COLLABORATION_DATA2, "KCF_COLLABORATION_DATA2");
    e->insert(KCF_COLLABORATION_END, "KCF_COLLABORATION_END");
);

Register_Class(WiseCameraKCFMsg_v2);

WiseCameraKCFMsg_v2::WiseCameraKCFMsg_v2(const char *name, int kind) : ::WiseApplicationPacket(name,kind)
{
    this->pktType_var = 0;
    this->trackingCount_var = 0;
    this->iterationStep_var = 0;
    this->targetID_var = 0;
    this->positionX_var = 0;
    this->positionY_var = 0;
    this->TypeNeighbour_var = 0;
    this->Vx_var = 0;
    this->Vy_var = 0;
}

WiseCameraKCFMsg_v2::WiseCameraKCFMsg_v2(const WiseCameraKCFMsg_v2& other) : ::WiseApplicationPacket(other)
{
    copy(other);
}

WiseCameraKCFMsg_v2::~WiseCameraKCFMsg_v2()
{
}

WiseCameraKCFMsg_v2& WiseCameraKCFMsg_v2::operator=(const WiseCameraKCFMsg_v2& other)
{
    if (this==&other) return *this;
    ::WiseApplicationPacket::operator=(other);
    copy(other);
    return *this;
}

void WiseCameraKCFMsg_v2::copy(const WiseCameraKCFMsg_v2& other)
{
    this->pktType_var = other.pktType_var;
    this->trackingCount_var = other.trackingCount_var;
    this->iterationStep_var = other.iterationStep_var;
    this->targetID_var = other.targetID_var;
    this->positionX_var = other.positionX_var;
    this->positionY_var = other.positionY_var;
    this->TypeNeighbour_var = other.TypeNeighbour_var;
    this->Vx_var = other.Vx_var;
    this->Vy_var = other.Vy_var;
    this->IF_u_var = other.IF_u_var;
    this->IF_U_var = other.IF_U_var;
}

void WiseCameraKCFMsg_v2::parsimPack(cCommBuffer *b)
{
    ::WiseApplicationPacket::parsimPack(b);
    doPacking(b,this->pktType_var);
    doPacking(b,this->trackingCount_var);
    doPacking(b,this->iterationStep_var);
    doPacking(b,this->targetID_var);
    doPacking(b,this->positionX_var);
    doPacking(b,this->positionY_var);
    doPacking(b,this->TypeNeighbour_var);
    doPacking(b,this->Vx_var);
    doPacking(b,this->Vy_var);
    doPacking(b,this->IF_u_var);
    doPacking(b,this->IF_U_var);
}

void WiseCameraKCFMsg_v2::parsimUnpack(cCommBuffer *b)
{
    ::WiseApplicationPacket::parsimUnpack(b);
    doUnpacking(b,this->pktType_var);
    doUnpacking(b,this->trackingCount_var);
    doUnpacking(b,this->iterationStep_var);
    doUnpacking(b,this->targetID_var);
    doUnpacking(b,this->positionX_var);
    doUnpacking(b,this->positionY_var);
    doUnpacking(b,this->TypeNeighbour_var);
    doUnpacking(b,this->Vx_var);
    doUnpacking(b,this->Vy_var);
    doUnpacking(b,this->IF_u_var);
    doUnpacking(b,this->IF_U_var);
}

unsigned int WiseCameraKCFMsg_v2::getPktType() const
{
    return pktType_var;
}

void WiseCameraKCFMsg_v2::setPktType(unsigned int pktType)
{
    this->pktType_var = pktType;
}

unsigned long WiseCameraKCFMsg_v2::getTrackingCount() const
{
    return trackingCount_var;
}

void WiseCameraKCFMsg_v2::setTrackingCount(unsigned long trackingCount)
{
    this->trackingCount_var = trackingCount;
}

unsigned long WiseCameraKCFMsg_v2::getIterationStep() const
{
    return iterationStep_var;
}

void WiseCameraKCFMsg_v2::setIterationStep(unsigned long iterationStep)
{
    this->iterationStep_var = iterationStep;
}

unsigned int WiseCameraKCFMsg_v2::getTargetID() const
{
    return targetID_var;
}

void WiseCameraKCFMsg_v2::setTargetID(unsigned int targetID)
{
    this->targetID_var = targetID;
}

double WiseCameraKCFMsg_v2::getPositionX() const
{
    return positionX_var;
}

void WiseCameraKCFMsg_v2::setPositionX(double positionX)
{
    this->positionX_var = positionX;
}

double WiseCameraKCFMsg_v2::getPositionY() const
{
    return positionY_var;
}

void WiseCameraKCFMsg_v2::setPositionY(double positionY)
{
    this->positionY_var = positionY;
}

unsigned int WiseCameraKCFMsg_v2::getTypeNeighbour() const
{
    return TypeNeighbour_var;
}

void WiseCameraKCFMsg_v2::setTypeNeighbour(unsigned int TypeNeighbour)
{
    this->TypeNeighbour_var = TypeNeighbour;
}

double WiseCameraKCFMsg_v2::getVx() const
{
    return Vx_var;
}

void WiseCameraKCFMsg_v2::setVx(double Vx)
{
    this->Vx_var = Vx;
}

double WiseCameraKCFMsg_v2::getVy() const
{
    return Vy_var;
}

void WiseCameraKCFMsg_v2::setVy(double Vy)
{
    this->Vy_var = Vy;
}

cv::Mat& WiseCameraKCFMsg_v2::getIF_u()
{
    return IF_u_var;
}

void WiseCameraKCFMsg_v2::setIF_u(const cv::Mat& IF_u)
{
    this->IF_u_var = IF_u;
}

cv::Mat& WiseCameraKCFMsg_v2::getIF_U()
{
    return IF_U_var;
}

void WiseCameraKCFMsg_v2::setIF_U(const cv::Mat& IF_U)
{
    this->IF_U_var = IF_U;
}

class WiseCameraKCFMsg_v2Descriptor : public cClassDescriptor
{
  public:
    WiseCameraKCFMsg_v2Descriptor();
    virtual ~WiseCameraKCFMsg_v2Descriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(WiseCameraKCFMsg_v2Descriptor);

WiseCameraKCFMsg_v2Descriptor::WiseCameraKCFMsg_v2Descriptor() : cClassDescriptor("WiseCameraKCFMsg_v2", "WiseApplicationPacket")
{
}

WiseCameraKCFMsg_v2Descriptor::~WiseCameraKCFMsg_v2Descriptor()
{
}

bool WiseCameraKCFMsg_v2Descriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<WiseCameraKCFMsg_v2 *>(obj)!=NULL;
}

const char *WiseCameraKCFMsg_v2Descriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int WiseCameraKCFMsg_v2Descriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 11+basedesc->getFieldCount(object) : 11;
}

unsigned int WiseCameraKCFMsg_v2Descriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISCOMPOUND,
        FD_ISCOMPOUND,
    };
    return (field>=0 && field<11) ? fieldTypeFlags[field] : 0;
}

const char *WiseCameraKCFMsg_v2Descriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "pktType",
        "trackingCount",
        "iterationStep",
        "targetID",
        "positionX",
        "positionY",
        "TypeNeighbour",
        "Vx",
        "Vy",
        "IF_u",
        "IF_U",
    };
    return (field>=0 && field<11) ? fieldNames[field] : NULL;
}

int WiseCameraKCFMsg_v2Descriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='p' && strcmp(fieldName, "pktType")==0) return base+0;
    if (fieldName[0]=='t' && strcmp(fieldName, "trackingCount")==0) return base+1;
    if (fieldName[0]=='i' && strcmp(fieldName, "iterationStep")==0) return base+2;
    if (fieldName[0]=='t' && strcmp(fieldName, "targetID")==0) return base+3;
    if (fieldName[0]=='p' && strcmp(fieldName, "positionX")==0) return base+4;
    if (fieldName[0]=='p' && strcmp(fieldName, "positionY")==0) return base+5;
    if (fieldName[0]=='T' && strcmp(fieldName, "TypeNeighbour")==0) return base+6;
    if (fieldName[0]=='V' && strcmp(fieldName, "Vx")==0) return base+7;
    if (fieldName[0]=='V' && strcmp(fieldName, "Vy")==0) return base+8;
    if (fieldName[0]=='I' && strcmp(fieldName, "IF_u")==0) return base+9;
    if (fieldName[0]=='I' && strcmp(fieldName, "IF_U")==0) return base+10;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *WiseCameraKCFMsg_v2Descriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "unsigned int",
        "unsigned long",
        "unsigned long",
        "unsigned int",
        "double",
        "double",
        "unsigned int",
        "double",
        "double",
        "cv::Mat",
        "cv::Mat",
    };
    return (field>=0 && field<11) ? fieldTypeStrings[field] : NULL;
}

const char *WiseCameraKCFMsg_v2Descriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int WiseCameraKCFMsg_v2Descriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    WiseCameraKCFMsg_v2 *pp = (WiseCameraKCFMsg_v2 *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string WiseCameraKCFMsg_v2Descriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    WiseCameraKCFMsg_v2 *pp = (WiseCameraKCFMsg_v2 *)object; (void)pp;
    switch (field) {
        case 0: return ulong2string(pp->getPktType());
        case 1: return ulong2string(pp->getTrackingCount());
        case 2: return ulong2string(pp->getIterationStep());
        case 3: return ulong2string(pp->getTargetID());
        case 4: return double2string(pp->getPositionX());
        case 5: return double2string(pp->getPositionY());
        case 6: return ulong2string(pp->getTypeNeighbour());
        case 7: return double2string(pp->getVx());
        case 8: return double2string(pp->getVy());
        case 9: {std::stringstream out; out << pp->getIF_u(); return out.str();}
        case 10: {std::stringstream out; out << pp->getIF_U(); return out.str();}
        default: return "";
    }
}

bool WiseCameraKCFMsg_v2Descriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    WiseCameraKCFMsg_v2 *pp = (WiseCameraKCFMsg_v2 *)object; (void)pp;
    switch (field) {
        case 0: pp->setPktType(string2ulong(value)); return true;
        case 1: pp->setTrackingCount(string2ulong(value)); return true;
        case 2: pp->setIterationStep(string2ulong(value)); return true;
        case 3: pp->setTargetID(string2ulong(value)); return true;
        case 4: pp->setPositionX(string2double(value)); return true;
        case 5: pp->setPositionY(string2double(value)); return true;
        case 6: pp->setTypeNeighbour(string2ulong(value)); return true;
        case 7: pp->setVx(string2double(value)); return true;
        case 8: pp->setVy(string2double(value)); return true;
        default: return false;
    }
}

const char *WiseCameraKCFMsg_v2Descriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 9: return opp_typename(typeid(cv::Mat));
        case 10: return opp_typename(typeid(cv::Mat));
        default: return NULL;
    };
}

void *WiseCameraKCFMsg_v2Descriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    WiseCameraKCFMsg_v2 *pp = (WiseCameraKCFMsg_v2 *)object; (void)pp;
    switch (field) {
        case 9: return (void *)(&pp->getIF_u()); break;
        case 10: return (void *)(&pp->getIF_U()); break;
        default: return NULL;
    }
}


