Multivariate normal distribution (C++)


* * * * *

# USAGE

Use pmvnorm\_P and pmvnorm\_Q to calculate CDF and upper tail of
CDF.

Read test.cpp for more details.

# About

This is a simple wrapper of R package libmvtnorm (or Fortran code
MVTDST). I put here just because I cannot find a handy C++
version.

# Contact

Please use
[github](https://github.com/zhanxw/libMvtnorm "https://github.com/zhanxw/libMvtnorm").



